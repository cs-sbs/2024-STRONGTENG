package org.example.entity;

public enum UserRole {
    user,
    admin
} 