package org.example.entity;

import lombok.Data;

@Data
public class BookCategory {
    private Long id;
    private String name;
} 